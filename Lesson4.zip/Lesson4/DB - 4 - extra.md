## Теория

- Buffer Cache: https://habr.com/ru/company/postgrespro/blog/458186/
- `WAL`: https://habr.com/ru/company/postgrespro/blog/459250/

- `Hash`: https://habr.com/ru/company/postgrespro/blog/442776/
- `B-Tree`: https://habr.com/ru/company/postgrespro/blog/443284/
- `GiST`: https://habr.com/ru/company/postgrespro/blog/444742/
- `GIN`: https://habr.com/ru/company/postgrespro/blog/448746/
- `RUM`: https://habr.com/ru/company/postgrespro/blog/452116/

- Транзакции: https://www.postgresql.org/docs/13/tutorial-transactions.html

- VACUUM: https://habr.com/ru/company/postgrespro/blog/484106/
- AUTOVACUUM: https://habr.com/ru/company/postgrespro/blog/486104/

- PgBouncer: https://postgrespro.ru/docs/postgrespro/10/pgbouncer
- Patroni: https://patroni.readthedocs.io/en/latest/ и https://habr.com/ru/post/504044/

- CAP и PACELC: https://habr.com/ru/post/328792/


### Большой курс по Postgres

- https://postgrespro.ru/education/courses/DBA1
- https://postgrespro.ru/education/courses/DEV1
